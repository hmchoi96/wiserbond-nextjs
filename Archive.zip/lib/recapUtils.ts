// lib/recapUtils.ts

import { differenceInDays, parseISO } from "date-fns";
import { fetchFREDSeries } from "./fetchers/fredFetcher";

export function shouldRecap(report: any): boolean {
  const today = new Date();
  const created = parseISO(report.created_at);
  const forecastWindow = parseInt(report.forecast_window || "90", 10);
  const daysSince = differenceInDays(today, created);
  return daysSince >= forecastWindow;
}

export async function fetchActualOutcome(topic: string, country: string): Promise<number | null> {
  const topicToSeries: Record<string, string> = {
    inflation: "CPIAUCSL",
    unemployment: "UNRATE",
    industrial: "INDPRO",
    gdp: "GDPA",
    sentiment: "UMCSENT"
  };

  const seriesId = topicToSeries[topic.toLowerCase()];
  if (!seriesId) return null;

  return await fetchFREDSeries(seriesId);
}

export function calculateAccuracy(predicted: string, actual: number): number {
  const predictedValue = parseFloat(predicted.match(/[-+]?[0-9]*\.?[0-9]+/g)?.[0] || "0");
  const error = Math.abs(predictedValue - actual);
  const accuracy = Math.max(0, 100 - error * 10); // 오차 1당 10% 감점
  return Math.round(accuracy * 10) / 10;
}
