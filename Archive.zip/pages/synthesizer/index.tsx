// pages/synthesizer/index.tsx
import { useState } from "react";
import ReportSection from "@/components/ReportSection";

interface ReportCard {
  id: string;
  title: string;
  type: string;
  content: string;
}

interface ReportResult {
  cards: ReportCard[];
  followup: string;
}

export default function SynthesizerPage() {
  const [topic, setTopic] = useState("");
  const [industry, setIndustry] = useState("");
  const [country, setCountry] = useState("");
  const [language, setLanguage] = useState("English");
  const [isPro, setIsPro] = useState(false);
  const [goal, setGoal] = useState("");
  const [situation, setSituation] = useState("");
  const [industryDetail, setIndustryDetail] = useState("");
  const [followupAnswers, setFollowupAnswers] = useState<string[]>([]);

  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ReportResult>({
    cards: [],
    followup: ""
  });

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          topic,
          industry,
          country,
          language,
          isPro,
          goal,
          situation,
          subIndustry: industryDetail,
          followup_answers: followupAnswers
        })
      });

      const data = await res.json();
      setResult(data);
    } catch (err) {
      console.error("Generation failed:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleFollowupChange = (index: number, value: string) => {
    const updated = [...followupAnswers];
    updated[index] = value;
    setFollowupAnswers(updated);
  };

  return (
    <div className="max-w-3xl mx-auto p-6 space-y-6">
      <h1 className="text-2xl font-bold">Wiserbond Synthesizer</h1>

      {/* 입력 영역 */}
      <div className="space-y-4">
        <input
          className="w-full border p-2 rounded"
          placeholder="Topic (e.g. Inflation)"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
        />
        <input
          className="w-full border p-2 rounded"
          placeholder="Industry (e.g. Supply Chain)"
          value={industry}
          onChange={(e) => setIndustry(e.target.value)}
        />
        <input
          className="w-full border p-2 rounded"
          placeholder="Country (e.g. Canada)"
          value={country}
          onChange={(e) => setCountry(e.target.value)}
        />
        <input
          className="w-full border p-2 rounded"
          placeholder="Goal (optional)"
          value={goal}
          onChange={(e) => setGoal(e.target.value)}
        />
        <input
          className="w-full border p-2 rounded"
          placeholder="Situation (optional)"
          value={situation}
          onChange={(e) => setSituation(e.target.value)}
        />
        <input
          className="w-full border p-2 rounded"
          placeholder="Industry Detail (optional)"
          value={industryDetail}
          onChange={(e) => setIndustryDetail(e.target.value)}
        />
        <select
          className="w-full border p-2 rounded"
          value={language}
          onChange={(e) => setLanguage(e.target.value)}
        >
          <option value="English">English</option>
          <option value="Korean">Korean</option>
          <option value="Spanish">Spanish</option>
        </select>
        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={isPro}
            onChange={() => setIsPro(!isPro)}
          />
          Pro Mode (expert-level explanation)
        </label>
        <button
          onClick={handleGenerate}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
          disabled={loading}
        >
          {loading ? "Generating..." : "Generate Report"}
        </button>
      </div>

      {/* 결과 카드 렌더링 */}
      <div className="space-y-4">
        {result.cards.map((card) => (
          <ReportSection
            key={card.id}
            id={card.id}
            title={card.title}
            content={card.content}
            /*type={card.type}*/
          />
        ))}

        {result.followup && (
          <div className="mt-6 p-4 border border-blue-200 bg-blue-50 rounded">
            <h2 className="font-bold text-lg text-blue-900 mb-2">
              🧠 Follow-up Questions
            </h2>
            <p className="text-sm text-blue-800 whitespace-pre-line mb-4">
              {result.followup}
            </p>

            <div className="space-y-2">
              {result.followup
                .split("\n")
                .filter((line) => line.trim().startsWith("-"))
                .map((q, idx) => (
                  <textarea
                    key={idx}
                    className="w-full border p-2 rounded text-sm"
                    placeholder={`Your answer to: ${q.replace("-", "").trim()}`}
                    value={followupAnswers[idx] || ""}
                    onChange={(e) => handleFollowupChange(idx, e.target.value)}
                  />
                ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
